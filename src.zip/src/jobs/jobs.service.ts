import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Job } from './job.entity';

@Injectable()
export class JobsService {
  constructor(
    @InjectRepository(Job)
    private jobRepo: Repository<Job>,
  ) {}

  create(job: Partial<Job>) {
    return this.jobRepo.save(job);
  }

  findAll() {
    return this.jobRepo.find();
  }

  findOne(id: number) {
    return this.jobRepo.findOne({ where: { id } });
  }

  async remove(id: number) {
    return this.jobRepo.delete(id);
  }
}