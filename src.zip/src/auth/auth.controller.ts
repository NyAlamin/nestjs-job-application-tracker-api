import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {

  constructor(private authService: AuthService) {}

  // Register API
  @Post('register')
  register(@Body() body: any) {
    return this.authService.register(body);
  }

  // Login API
  @Post('login')
  login(@Body() body: any) {
    return this.authService.login(body);
  }

}