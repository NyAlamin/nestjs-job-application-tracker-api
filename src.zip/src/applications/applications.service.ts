import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Application } from './application.entity';

@Injectable()
export class ApplicationsService {
  constructor(
    @InjectRepository(Application)
    private appRepo: Repository<Application>,
  ) {}

  create(application: Partial<Application>) {
    return this.appRepo.save(application);
  }

  findAll() {
    return this.appRepo.find();
  }

  findOne(id: number) {
    return this.appRepo.findOne({ where: { id } });
  }

  async updateStatus(id: number, status: string) {
    await this.appRepo.update(id, { status });
    return this.findOne(id);
  }

  async remove(id: number) {
    return this.appRepo.delete(id);
  }
}