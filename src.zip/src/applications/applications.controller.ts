import { Body, Controller, Get, Post, Param, Patch, Delete } from '@nestjs/common';
import { ApplicationsService } from './applications.service';
import { Application } from './application.entity';

@Controller('applications')
export class ApplicationsController {
  constructor(private appService: ApplicationsService) {}

  @Post()
  apply(@Body() body: Application) {
    return this.appService.create(body);
  }

  @Get()
  findAll() {
    return this.appService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.appService.findOne(id);
  }

  @Patch(':id/status')
  updateStatus(@Param('id') id: number, @Body('status') status: string) {
    return this.appService.updateStatus(id, status);
  }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.appService.remove(id);
  }
}